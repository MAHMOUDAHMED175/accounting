class AppConstants {
  // static const int splashDelay = 2;
  // static const int sliderAnimationTime = 300;
}
