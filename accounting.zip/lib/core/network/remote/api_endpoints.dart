
//http://oceantecsa-001-site1.etempurl.com/api/Accounts
class ApiEndPoints {
  static const String domainLink =
      'http://oceantecsa-001-site1.etempurl.com/api/';
  static const String accountsEndPoint = 'Accounts';
}
