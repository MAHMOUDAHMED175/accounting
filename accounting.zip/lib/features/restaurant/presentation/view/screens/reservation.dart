
import 'package:flutter/material.dart';

class RestaurantReservation extends StatelessWidget {
  const RestaurantReservation({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[200],
      width: double.infinity,
    );
  }
}
