
import 'package:flutter/material.dart';

class RestaurantPrinterSettings extends StatelessWidget {
  const RestaurantPrinterSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[200],
      width: double.infinity,
    );
  }
}
