
import 'package:flutter/material.dart';

class RestaurantKitchen extends StatelessWidget {
  const RestaurantKitchen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[200],
      width: double.infinity,
    );
  }
}
