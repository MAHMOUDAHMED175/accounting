
abstract class RestaurantState {}

class RestaurantInitial extends RestaurantState {}
class restaurantChangeIndexState extends RestaurantState {}
class changeGridViewViewerState extends RestaurantState {}
