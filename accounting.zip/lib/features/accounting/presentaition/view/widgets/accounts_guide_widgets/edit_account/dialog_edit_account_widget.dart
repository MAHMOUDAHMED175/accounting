import 'package:flutter/material.dart';

import 'content_edit_account_dialog.dart';

Dialog editAccountDialog(
  BuildContext context,
) {
  return const Dialog(
    child: ContentEditAccountDialog(),
  );
}
