import 'package:flutter/material.dart';

import 'content_add_account_dialog.dart';

Dialog AddAccountDialog() {
  return Dialog(
    child: ContentAddAccountDialog(),
  );
}
