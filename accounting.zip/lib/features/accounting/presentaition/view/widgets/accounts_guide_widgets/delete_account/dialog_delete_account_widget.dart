import 'package:flutter/material.dart';

import 'content_delete_account_dialog.dart';

Dialog deleteAccountDialog(
  BuildContext context,
) {
  return Dialog(
    child: ContentDeleteAccountDialog(),
  );
}
