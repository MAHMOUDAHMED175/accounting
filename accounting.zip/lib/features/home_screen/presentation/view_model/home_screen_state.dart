
abstract class HomeScreenState {}

class HomeScreenInitial extends HomeScreenState {}
class changeOpenSideState extends HomeScreenState {}
class changeIndexSideMenuState extends HomeScreenState {}
class chartHomeScreenChangeIndexSideMenuState extends HomeScreenState {}
class losingChangeIndexState extends HomeScreenState {}
class lightChangeState extends HomeScreenState {}
