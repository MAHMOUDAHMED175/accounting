package com.example.accounting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
